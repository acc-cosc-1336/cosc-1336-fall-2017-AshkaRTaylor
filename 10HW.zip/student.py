class Student:

    def __init__(self,s,f,l,e):
        self.student_id = s
        self.first_name = f
        self.last_name = l
        self.enroll_data = e