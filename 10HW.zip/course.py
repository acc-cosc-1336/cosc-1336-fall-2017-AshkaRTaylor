class Course:

    def __init__(self, id, c, s):

        self.course_id = id
        self.title = c
        self.student = s

