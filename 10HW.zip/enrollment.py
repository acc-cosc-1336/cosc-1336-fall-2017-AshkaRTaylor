class Enrollment:

    def __init__(self, id, s, c):

        self.enroll_id = id
        self.course = c
        self.student = s
        self.grade = ''



